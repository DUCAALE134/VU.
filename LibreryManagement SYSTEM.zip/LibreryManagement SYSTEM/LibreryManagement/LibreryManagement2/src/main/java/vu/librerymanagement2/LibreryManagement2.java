package vu.librerymanagement2;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class LibreryManagement2 extends javax.swing.JFrame {

    private JTextField bookIDField, titleField, authorField, yearField;
   private JTable bookTable;
   private DefaultTableModel tableModel;
  public LibreryManagement2() {
        setTitle("Library Manager");
        setLayout(new BorderLayout());
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      // Form Panel
     JPanel formPanel = new JPanel(new GridLayout(5, 2));
     formPanel.add(new JLabel("Book ID:"));
       bookIDField = new JTextField();
       formPanel.add(bookIDField);

       formPanel.add(new JLabel("Title:"));
       titleField = new JTextField();
       formPanel.add(titleField);
     formPanel.add(new JLabel("Author:"));
       authorField = new JTextField();
       formPanel.add(authorField);

        formPanel.add(new JLabel("Year:"));
        yearField = new JTextField();
        formPanel.add(yearField);
       JButton addButton = new JButton("Add Book");
       formPanel.add(addButton);
        addButton.addActionListener(new AddBookAction());

       add(formPanel, BorderLayout.NORTH);
         //Table Panel
        tableModel = new DefaultTableModel(new String[]{"Book ID", "Title", "Author", "Year"}, 0);
        bookTable = new JTable(tableModel);
        add(new JScrollPane(bookTable), BorderLayout.CENTER);

         //Button Panel
       JPanel buttonPanel = new JPanel();
        JButton deleteButton = new JButton("Delete Book");
        deleteButton.addActionListener(new DeleteBookAction());
        buttonPanel.add(deleteButton);

       JButton refreshButton = new JButton("Refresh List");
       refreshButton.addActionListener(new RefreshListAction());
       buttonPanel.add(refreshButton);

       add(buttonPanel, BorderLayout.SOUTH);
       pack();
       setLocationRelativeTo(null);
       setVisible(true);

       refreshBookList();
    }

    private void refreshBookList() {
       try (Connection connection = DriverManager.getConnection("jdbc:ucanaccess://C://Users//khali//Desktop//couse work//Apps//Library.accdb\";")) {
           Statement statement = connection.createStatement();
           ResultSet resultSet = statement.executeQuery("SELECT * FROM Books");
            tableModel.setRowCount(0);
            while (resultSet.next()) {
                tableModel.addRow(new Object[]{
                        resultSet.getString("BookID"),
                        resultSet.getString("Title"),
                        resultSet.getString("Author"),
                        resultSet.getInt("Year")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private class AddBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try (Connection connection = DriverManager.getConnection("jdbc:ucanaccess://C://Users//khali//Desktop//couse work//Apps//Library.accdb\";")) {
                String sql = "INSERT INTO Books (BookID, Title, Author, Year) VALUES (?, ?, ?, ?)";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, bookIDField.getText());
                preparedStatement.setString(2, titleField.getText());
                preparedStatement.setString(3, authorField.getText());
                preparedStatement.setInt(4, Integer.parseInt(yearField.getText()));
                preparedStatement.executeUpdate();
                JOptionPane.showMessageDialog(LibreryManagement2.this, "Book added successfully!");
                refreshBookList();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
   private class DeleteBookAction implements ActionListener {
       @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(LibreryManagement2.this, "No book selected.");
                return;
            }
            String bookID = (String) bookTable.getValueAt(selectedRow, 0);
            try (Connection connection = DriverManager.getConnection("jdbc:ucanaccess://C://Users//khalid//Desktop//couse work//Apps//Library.accdb\";")) {
                String sql = "DELETE FROM Books WHERE BookID = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, bookID);
               preparedStatement.executeUpdate();
                JOptionPane.showMessageDialog(LibreryManagement2.this, "Book deleted successfully!");
                refreshBookList();
            } catch (SQLException ex) {
                ex.printStackTrace();
           }
       }
   }

    private class RefreshListAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            refreshBookList();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LibreryManagement2::new);
}
}